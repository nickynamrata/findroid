FinDroid app is basically a service app consisting no graphical user interface (GUI)
FinDroidSetting app contains the UI of the FinDroid app through which user can change the necessary settings.